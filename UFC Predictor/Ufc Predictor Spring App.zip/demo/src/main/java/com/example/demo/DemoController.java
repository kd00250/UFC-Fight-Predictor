package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import edu.westga.cs1302.javafx_sample.Main;

@RestController
public class DemoController {

	// Endpoint to trigger Main.main()
    @GetMapping("/api/run-main")
    public String runMain(@RequestParam String arg1, @RequestParam String arg2) {
        // Collect arguments from query parameters
        String[] args = { arg1, arg2 };

        try {
            // Pass args to Main.main()
            Main.main(args);
            return "Java code triggered successfully with arguments: " + String.join(", ", args);
        } catch (Exception e) {
            return "Error triggering Java code: " + e.getMessage();
        }
    }
}
